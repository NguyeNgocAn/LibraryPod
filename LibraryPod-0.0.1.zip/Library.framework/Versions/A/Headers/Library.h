//
//  Library.h
//  Library
//
//  Created by MacMini on 03/05/2022.
//

#import <Foundation/Foundation.h>

@interface Library : NSObject
- (double)sum:(double)x and:(double)y;

- (double)mutiplication:(double)x and:(double)y;

- (double)subtraction:(double)x and:(double)y;

- (double)division:(double)x and:(double)y;
@end
